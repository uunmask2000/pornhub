
import urllib3
import re
import time
import os
import requests
import sys
###
from pget.down import Downloader
from bs4 import BeautifulSoup

urllib3.disable_warnings()


def download_chunk_count(url, filename, chunk_count=10):
    print('start  ：')
    start = time.time()
    downloader = Downloader(url, filename, chunk_count, True)
    downloader.start_sync()
    end = time.time()
    print('Finish in ：', end - start)
    return True


def download_(url, path):
    print('start  ：')
    start = time.time()
    # -----------------------------------------------------------------------------

    # print(video_time_)
    if os.path.isfile(path):
        print('档案存在')

    r1 = requests.get(url, stream=True, verify=False)
    total_size = int(r1.headers['Content-Length'])

    # 这重要了，先看看本地档案下载了多少
    if os.path.exists(path):
        temp_size = os.path.getsize(path)  # 本地已经下载的档案大小
    else:
        temp_size = 0
    # 显示一下下载了多少
    print(temp_size)
    print(total_size)
    # 核心部分，这个是请求下载时，从本地档案已经下载过的后面下载
    headers = {'Range': 'bytes=%d-' % temp_size}
    # 重新请求网址，加入新的请求头的
    r = requests.get(url, stream=True, verify=False, headers=headers)

    # 下面写入档案也要注意，看到"ab"了吗？
    # "ab"表示追加形式写入档案
    with open(path, "ab") as f:
        for chunk in r.iter_content(chunk_size=1024*1024):
            if chunk:
                temp_size += len(chunk)
                f.write(chunk)
                f.flush()

                ###这是下载实现进度显示####
                done = int(50 * temp_size / total_size)
                sys.stdout.write("\r[%s%s] %d%%" % (
                    '█' * done, ' ' * (50 - done), 100 * temp_size / total_size))
                sys.stdout.flush()
    print()  # 避免上面\r 回车符
    # -----------------------------------------------------------------------------

    end = time.time()
    print('Finish in ：', end - start)
    return True


def _web_(___url):
    headers = {'user-agent': 'my-app/0.0.1'}
    res = requests.get(___url, headers=headers, verify=False)
    # html = res.content.decode("utf-8")
    html = res.content
    soup = BeautifulSoup(html, 'html.parser')
    return soup


def singe_url(__url):
    soup = _web_(__url)

    result_ = re.search('file: "(.*?)",', soup.decode("utf-8"))
    try:
        mp4 = result_.group(1).replace('\\', '')
    except:
        return False

    # mp4 = result_.group(1).replace('\\', '')

    title_ = soup.find("meta",  property="og:title").get('content')
    pink_link = soup.find("a", {"class": "pink_link"}).text
    path = 'mp4'
    if not os.path.isdir(path):
        os.mkdir(path)

    path = 'mp4/' + pink_link + '/'
    if not os.path.isdir(path):
        os.mkdir(path)
    path = path + title_ + '.mp4'
    # print(title_)
    # print(path)
    # pink_link

    print(pink_link, '下载', path)
    ###
    # download_(mp4, path)
    # download_chunk_count(mp4, path)

    return True


def list_uuk(__url):
    soup = _web_(__url)
    # col-12 col-lg-8
    # print(soup)
    div_ = soup.find_all('div', {'class': "card-body purple-card"})
    print(len(div_))
    if len(div_) == 0:
        return False

    for list__ in div_:
        xx = list__.find('a').text
        href = list__.find('a').get('href')
        print(xx,  ' : ', href)
        singe_url(href)
    return True


# url = 'https://www.helloavgirls.com/av/168'
# singe_url(url)

url = 'https://www.helloavgirls.com/search/%E5%A4%A7%E6%A9%8B%E6%9C%AA%E4%B9%85/5'

url = url + '/{}'
##
# page = 10
# _url = url.format(page)
# res = list_uuk(_url)
# print('SSSS', res)
# ##

page = 0
while True:
    page += 1
    _url = url.format(page)
    res = list_uuk(_url)
    print('SSSS', res,   page)
    if res == False:
        break
